
This "contrib" directory contains contributions which are not necessarily under
the libpng license, although all are open source.  They are not part of
libpng proper and are not used for building the library.
